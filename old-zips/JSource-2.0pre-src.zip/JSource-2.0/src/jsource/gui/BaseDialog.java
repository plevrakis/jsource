package jsource.gui;


/**
 * BaseDialog.java  01/02/03
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 */
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import jsource.util.JSConstants;


/**
 * <code>BaseDialog</code> is an abstract dialog box that handles window closing,
 * the ENTER key and the ESCAPE key. All that has to be done is implementing ok()
 * (called when Enter is pressed) and cancel() (called when Escape is pressed, or window is closed).
 *
 * @author Panagiotis Plevrakis
 * <br>Based on related jEdit class
 * <br>Email: pplevrakis@hotmail.com
 * <br>URL:   http://jsource.sourceforge.net
 */
public abstract class BaseDialog extends JDialog implements JSConstants{
    BaseDialog(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        setModal(false);

        ((Container) getLayeredPane()).addContainerListener(
                new ContainerHandler());
        getContentPane().addContainerListener(new ContainerHandler());

        keyHandler = new KeyHandler();
        addKeyListener(keyHandler);
        addWindowListener(new WindowHandler());
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    }

    public abstract void ok();

    public abstract void cancel();

    // protected members
    protected KeyHandler keyHandler;

    // Recursively adds our key listener to sub-components
    class ContainerHandler extends ContainerAdapter {
        public void componentAdded(ContainerEvent evt) {
            componentAdded(evt.getChild());
        }

        public void componentRemoved(ContainerEvent evt) {
            componentRemoved(evt.getChild());
        }

        private void componentAdded(Component comp) {
            comp.addKeyListener(keyHandler);
            if (comp instanceof Container) {
                Container cont = (Container) comp;

                cont.addContainerListener(this);
                Component[] comps = cont.getComponents();

                for (int i = 0; i < comps.length; i++) {
                    componentAdded(comps[i]);
                }
            }
        }

        private void componentRemoved(Component comp) {
            comp.removeKeyListener(keyHandler);
            if (comp instanceof Container) {
                Container cont = (Container) comp;

                cont.removeContainerListener(this);
                Component[] comps = cont.getComponents();

                for (int i = 0; i < comps.length; i++) {
                    componentRemoved(comps[i]);
                }
            }
        }
    }


    class KeyHandler extends KeyAdapter {
        public void keyPressed(KeyEvent evt) {
            if (evt.isConsumed())
                return;

            if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                // crusty workaround
                Component comp = getFocusOwner();

                while (comp != null) {
                    if (comp instanceof JComboBox) {
                        JComboBox combo = (JComboBox) comp;

                        if (combo.isEditable()) {
                            Object selected = combo.getEditor().getItem();

                            if (selected != null)
                                combo.setSelectedItem(selected);
                        }
                        break;
                    }

                    comp = comp.getParent();
                }

                ok();
                evt.consume();
            } else if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
                cancel();
                evt.consume();
            }
        }
    }


    class WindowHandler extends WindowAdapter {
        public void windowClosing(WindowEvent evt) {
            cancel();
        }
    }
}
