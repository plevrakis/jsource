package jsource;


/**
 * @(#)JavaIDE.java	03/29/02
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.plaf.metal.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import javax.swing.plaf.*;
import javax.swing.event.*;
import javax.swing.colorchooser.*;
import java.io.*;
import java.util.*;
import com.incors.plaf.*;
import com.incors.plaf.kunststoff.*;
import com.incors.plaf.kunststoff.themes.*;


/**
 * JavaIDE holds all the GUI components of the application
 *
 * @author	Panagiotis Plevrakis
 * @author	Richard Dutton
 * @author	Andrei Erdoss
 *
 * Email: pplevrakis@hotmail.com
 * URL:   http://jsource.sourceforge.net/
 */
public class JavaIDE extends JFrame {
    private boolean debug = false; //set to true for debugging messages

	// font & background
	protected static String[] fontStyles = { "Font.PLAIN", "Font.BOLD", "Font.ITALIC" };
	protected static int[] styles = { Font.PLAIN, Font.BOLD, Font.ITALIC };
	protected static int[] sizes = { 10, 11, 12, 14, 16, 18 };
	protected static String[] fontSizes = { "10", "11", "12", "14", "16", "18" };
    protected static Color currentBgColor, currentFgColor;
	protected static String currentFont;
    protected static int currentStyle, currentSize;

	// run
	private Interpreter inp;

	// jdk
    protected boolean isjdk;
    protected String jdk;

	// files
    protected static String currentFile;
	protected final static String dir = System.getProperty("user.dir");
    protected final static String fs = System.getProperty("file.separator");
    protected File root, f, currFile;
    protected boolean javaFile = false;
    protected final static String templatePath = "jsource" + fs + "templates" + fs;

	// editor area
	protected static JDesktopPane desktop;
	protected static JInternalFrame currFrame;
	protected static JTextPane editor;
	protected static Document doc;

    /**
     * Creates a new JavaIDE object.
     */
    public JavaIDE() {
        super("JSource IDE v 1.2");
        setKunststoffLookAndFeel(new KunststoffCharcoalTheme());
        setDefaultLookAndFeelDecorated(true);
		// files & dir
        f = new File("jsource" + fs + "jdk.ser");
        root = new File(dir);
        // current fonts & bg
		currentFont = "Courier New";
        currentStyle = styles[0];
        currentSize = sizes[3];
		currentBgColor = Color.black;
        currentFgColor = Color.white;
		// setup desktop
		desktop = new JDesktopPane();
		desktop.setLayout(new BorderLayout());
		desktop.setDragMode(JDesktopPane.LIVE_DRAG_MODE);
		// setup menubar
		setJMenuBar(setMenuBar());
		// setup toolbars
		JToolBar toolBar1 = new JToolBar();
		setToolBar1(toolBar1);
		//JPanel toolBar1Panel = new JPanel();
		//toolBar1Panel.add(toolBar1);
		JToolBar toolBar2 = new JToolBar();
		setToolBar2(toolBar2);
		//JPanel toolBar2Panel = new JPanel();
		//toolBar2Panel.add(toolBar2);
		JPanel toolBarsPane = new JPanel();
		toolBarsPane.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		toolBarsPane.add(toolBar2);
		toolBarsPane.add(toolBar1);
		desktop.add(toolBarsPane, BorderLayout.NORTH);
		// open document
        createFrame();
		editor.setFont(new Font(currentFont, currentStyle, currentSize));
        editor.setBackground(currentBgColor);
        editor.setForeground(currentFgColor);
		// add desktop to frame
		setContentPane(desktop);
    }

	/**
	 * Creates new internal frame
	 * @author Andrei Erdoss
	 * @param
	 * @return
	 */
    protected void createFrame() {
        final InternalFrame frame = new InternalFrame();
		frame.setFont(new Font(currentFont, currentStyle, currentSize));
		frame.setVisible(true);

		frame.addInternalFrameListener(new InternalFrameAdapter() {
		public void internalFrameActivated(InternalFrameEvent ife) {
			currFrame=frame;
		}});

        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
		editor = frame.editor;
		doc = frame.editor.getDocument();
		currFrame = frame;
    }

    private void showExceptionErrorMessage(String s) {
        JOptionPane.showMessageDialog(this, s, s, JOptionPane.ERROR_MESSAGE);
    }

	/**
	 * get a file to open
	 * @author Panagiotis Plevrakis
	 * @param
	 * @return
	 */
    private File getAFileToOpen() {
		createFrame();
        File file = null;
        File currentdirectory = new File(".");
        JFileChooser filechooser = new JFileChooser(currentdirectory);
        int replycode = filechooser.showOpenDialog(this);
        if (replycode == JFileChooser.APPROVE_OPTION) {
            file = filechooser.getSelectedFile();
            String f = filechooser.getName(file);
            if (file != null)
                currentFile = f;
            if (file.getName().endsWith(".java"))
                javaFile = true;
        }
        return file;
    }

	/**
	 * get a file to save
	 * @author Panagiotis Plevrakis
	 * @param
	 * @return
	 */
    private File getAFileForSave() {
        File file = null;
        File currentdirectory = new File(".");
        JFileChooser filechooser = new JFileChooser(currentdirectory);
        int replycode = filechooser.showSaveDialog(this);
        if (replycode == JFileChooser.APPROVE_OPTION) {
            file = filechooser.getSelectedFile();
            String f = filechooser.getName(file);
            if (file != null)
                currentFile = f;
            if (file.getName().endsWith(".java"))
                javaFile = true;
        }
        currFrame.setTitle(currentFile);
        return file;
    }

	/**
	 * Displays a file to the editor
	 * @author Panagiotis Plevrakis
	 * @author Andrei Erdoss
	 * @param file the File to display
	 */
    private void writeFileToEditor(File file) {
		editor.setText("");
        try {
            FileReader filereader = new FileReader(file);
            BufferedReader bufferedreader = new BufferedReader(filereader);
			StreamTokenizer st = new StreamTokenizer(bufferedreader);
			st.ordinaryChar(' '); st.ordinaryChar('.');
			st.ordinaryChar('('); st.ordinaryChar(')');
			st.ordinaryChar('/'); st.ordinaryChar('\t');
			st.ordinaryChar('\"'); st.ordinaryChar('\'');
			st.slashSlashComments(false); st.slashStarComments(false);
			st.eolIsSignificant(true);
            while (st.nextToken() != StreamTokenizer.TT_EOF) {
				if(st.ttype == st.TT_WORD) {
					if(isKeyword(st.sval))
					   doc.insertString(editor.getCaretPosition(), ""+st.sval,
										 editor.getStyle("keyword"));
					else
						doc.insertString(editor.getCaretPosition(), ""+st.sval,
								 editor.getStyle("plain"));
				} else if(st.ttype == st.TT_NUMBER) {
					doc.insertString(editor.getCaretPosition(), ""+(int)st.nval,
								 editor.getStyle("plain"));
				} else {
					doc.insertString(editor.getCaretPosition(), ""+(char)st.ttype,
								 editor.getStyle("plain"));
				}
			}
            filereader.close();
		} catch (Exception e) {}
		currFrame.setTitle(currentFile);
    }

	/**
	 * save file
	 * @author Panagiotis Plevrakis
	 * @param File file, String s
	 * @return
	 */
    private void writeStringToFile(File file, String s) {
        try {
            FileWriter filewriter = new FileWriter(file);
            StringReader stringreader = new StringReader(s);
            BufferedReader bufferedreader = new BufferedReader(stringreader);
            String lineread = "";
            while ((lineread = bufferedreader.readLine()) != null) {
                filewriter.write(lineread + "\r\n");
            }
            filewriter.close();
        } catch (FileNotFoundException fnfe) {
            System.err.println("FileNotFoundException: " + fnfe.getMessage());
            showExceptionErrorMessage("FileNotFoundException: " + fnfe.getMessage());
        } catch (IOException ioe) {
            System.err.println("IOException: " + ioe.getMessage());
            showExceptionErrorMessage("IOException: " + ioe.getMessage());
        }
    }

    public void showMessage(String s) {
        JOptionPane.showMessageDialog(this, s);
    }

    /**
     * Retrieves all the available system font styles and stores them in an
     * ArrayList. Font names longer than 15 characters can be removed for GUI
     * layout purposes by uncommenting the code below.
     * @author Panagiotis Plevrakis
	 * @return String[] all system fonts
     */
    private String[] getFonts() {
        int i;
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Font allFonts[] = ge.getAllFonts();
        java.util.List f = new ArrayList();

        for (int k = 0; k < allFonts.length; k++)
            f.add(allFonts[k].getName());

        /* uncomment to remove font names longer than 15 characters
        Iterator it = f.iterator();
        while (it.hasNext()) {
            if (it.next().toString().length() > 15) it.remove();
        }*/

        Object fonts[] = f.toArray();
        String fonts2[] = new String[fonts.length];

        for (int m = 0; m < fonts.length; m++) {
            fonts2[m] = new String(fonts[m].toString());
        }
        return fonts2;
    }

	/**
	 * setup menubar
	 * @author Richard Dutton
	 * @author Andrei Erdoss
	 * @param
	 * @return
	 */
	public JMenuBar setMenuBar() {
		final BrowserListener brs = new BrowserListener(this);
        JMenuBar menuBar = new JMenuBar();
		JMenu menu;
		JMenuItem menuItem;
		// file
        menu = new JMenu("File");
			// new
			menuItem = new JMenuItem("New");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {createFrame();}});
        	menu.add(menuItem);
			// open
			menuItem = new JMenuItem("Open");
			menuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					currFile = getAFileToOpen();
					if (currFile != null) {
						writeFileToEditor(currFile);
						editor.setCaretPosition(1);
					}
				}
			});
			menu.add(menuItem);
			// close
			menuItem = new JMenuItem("Close");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {currFrame.dispose();}});
			menu.add(menuItem);
			// separator
			menu.addSeparator();
			// save
			menuItem = new JMenuItem("Save");
			menuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
			        String s = editor.getText();
					currFile = getAFileForSave();
					if (currFile != null) {
						writeStringToFile(currFile, s);
						showMessage("File saved as " + currFile.getName());
					}
				}
			});
			menu.add(menuItem);
			// save as
			menuItem = new JMenuItem("Save As");
			menu.add(menuItem);
			// separator
			menu.addSeparator();
			// exit
			menuItem = new JMenuItem("Exit");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {System.exit(0);}});
			menu.add(menuItem);
			// add to menubar
			menuBar.add(menu);
		// edit
		menu = new JMenu("Edit");
			// cut
			menuItem = new JMenuItem("Cut");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {editor.cut();}});
			menu.add(menuItem);
			// copy
			menuItem = new JMenuItem("Copy");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {editor.copy();}});
			menu.add(menuItem);
			// paste
			menuItem = new JMenuItem("Paste");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {editor.paste();}});
			menu.add(menuItem);
			// font color
			menuItem = new JMenuItem("Font Color");
			menuItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    currentFgColor = JColorChooser.showDialog(
                                JavaIDE.this, "Choose Font Color",
                                editor.getForeground());
                    if (currentFgColor != null)
                        editor.setForeground(currentFgColor);
                }
            });
			menu.add(menuItem);
			// background color
			menuItem = new JMenuItem("Background Color");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				currentBgColor = JColorChooser.showDialog(
                                JavaIDE.this, "Choose Background Color",
                                editor.getBackground());
                if (currentBgColor != null)
					editor.setBackground(currentBgColor);
                }
            });
			menu.add(menuItem);
			// add to menubar
			menuBar.add(menu);
		// view
		menu = new JMenu("View");
			// browser
			menuItem = new JMenuItem("In Web Browser");
			menuItem.addActionListener(brs);
			menu.add(menuItem);
			// add to menubar
			menuBar.add(menu);
        // tools
		menu = new JMenu("Tools");
			// compile
			menuItem = new JMenuItem("Compile");
			menuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					if (editor.getText().equals(""))
						JOptionPane.showMessageDialog(null, "No file to compile!",
                            "ERROR!", JOptionPane.ERROR_MESSAGE);

					if (javaFile == false)
						JOptionPane.showMessageDialog(null, "This is not a Java file!",
                            "ERROR!", JOptionPane.ERROR_MESSAGE);
					else
						compile(currFile.getPath(), true);
				}
			});
			menu.add(menuItem);
			// decompile
			menuItem = new JMenuItem("Decompile");
			menuItem.addActionListener(new Decompiler(this));
			menu.add(menuItem);
			// run application
			menuItem = new JMenuItem("Run Application");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				if (editor.getText().equals(""))
                       JOptionPane.showMessageDialog(null, "No file to run!",
                           "ERROR!", JOptionPane.ERROR_MESSAGE);
                else
					inp.run(currentFile, "java", jdk);
				}
            }
			);
			menu.add(menuItem);
			// run
			menuItem = new JMenuItem("Run Applet");
			menu.add(menuItem);
			menuBar.add(menu);
		//templates
		menu = new JMenu("Templates");
		JMenu subMenu = null;
		    // GUI templates
			subMenu = new JMenu("GUI Templates");
			// GridBagConstraints
			menuItem = new JMenuItem("GridBagConstraints");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "GridBagConstraints.txt"));}});
			subMenu.add(menuItem);
			menu.add(subMenu);

			// Bean templates
			subMenu = new JMenu("Bean Templates");
			// setter method
			menuItem = new JMenuItem("Setter Method");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "setterMethod.txt"));}});
			subMenu.add(menuItem);
			// getter method
			menuItem = new JMenuItem("Getter Method");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "getterMethod.txt"));}});
			subMenu.add(menuItem);
			menu.add(subMenu);

			// Documentation templates
			subMenu = new JMenu("JavaDoc Templates");
			// class description
			menuItem = new JMenuItem("Class Description");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "classDescription.txt"));}});
			subMenu.add(menuItem);
			menu.add(subMenu);

			// Debug templates
			subMenu = new JMenu("Debug Templates");
			// System.err
			menuItem = new JMenuItem("System.err");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "SystemErr.txt"));}});
			subMenu.add(menuItem);
			// System.out
			menuItem = new JMenuItem("System.out");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "SystemOut.txt"));}});
			subMenu.add(menuItem);
			menu.add(subMenu);

			// Loop templates
			subMenu = new JMenu("Loop Templates");
			// switch block
			menuItem = new JMenuItem("Switch");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "switch.txt"));}});
			subMenu.add(menuItem);
			// if else block
			menuItem = new JMenuItem("If-else");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "ifelse.txt"));}});
			subMenu.add(menuItem);
			// for block
			menuItem = new JMenuItem("For");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "for.txt"));}});
			subMenu.add(menuItem);
			// while block
			menuItem = new JMenuItem("While");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "while.txt"));}});
			subMenu.add(menuItem);
			menu.add(subMenu);

			// General templates
			subMenu = new JMenu("More Templates");
			// try block
			menuItem = new JMenuItem("Try");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "try.txt"));}});
			subMenu.add(menuItem);
			// enumeration
			menuItem = new JMenuItem("Enumeration");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				insertTemplate(new File(templatePath + "enum.txt"));}});
			subMenu.add(menuItem);
			menu.add(subMenu);
			menuBar.add(menu);
        // help
		menu = new JMenu("Help");
			// usage help
			menuItem = new JMenuItem("Usage");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				new Help("JSource Usage");}});
			menu.add(menuItem);
			// set jdk
			menuItem = new JMenuItem("Set JDK");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				setJavaHome();}});
			menu.add(menuItem);
			// set web browser
			menuItem = new JMenuItem("Set Web Browser");
			menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				brs.setBrowserHome();}});
			menu.add(menuItem);
			menuBar.add(menu);

		menuBar.setVisible(true);
		return menuBar;
	}

	/**
	 * setup toolbar2
	 * @author Panagiotis Plevrakis
	 * @author Andrei Erdoss
	 * @param
	 * @return
	 */
	public void setToolBar2(JToolBar toolBar) {
		JButton button;
		// new
		button = new JButton(new ImageIcon("jsource" + fs + "new.jpg"));
        button.setToolTipText("New File");
        button.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent evt) {createFrame();}});
		toolBar.add(button);
		// open
        button = new JButton(new ImageIcon("jsource" + fs + "open.jpg"));
        button.setToolTipText("Open File");
        button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				currFile = getAFileToOpen();
				if (currFile != null) { writeFileToEditor(currFile);
					editor.setCaretPosition(1);
				}
			} });
		toolBar.add(button);
		// save
		button = new JButton(new ImageIcon("jsource" + fs + "save.jpg"));
        button.setToolTipText("Save File");
        button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
		        String s = editor.getText();
				currFile = getAFileForSave();
				if (currFile != null) { writeStringToFile(currFile, s);
					showMessage("File saved as " + currFile.getName());
				}
			} });
		toolBar.add(button);
		// cut
		button = new JButton(new ImageIcon("jsource" + fs + "cut.jpg"));
		button.setToolTipText("Cut");
		button.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent evt) {editor.cut();}});
		toolBar.add(button);
		// copy
        button = new JButton(new ImageIcon("jsource" + fs + "copy.jpg"));
		button.setToolTipText("Copy");
		button.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent evt) {editor.copy();}});
		toolBar.add(button);
		// paste
        button = new JButton(new ImageIcon("jsource" + fs + "paste.jpg"));
		button.setToolTipText("Paste");
		button.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent evt) {editor.paste();}});
		toolBar.add(button);
		// compile
		button = new JButton(new ImageIcon("jsource" + fs + "compile.jpg"));
        button.setToolTipText("Compile");
        button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				if (editor.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "No file to compile!",
                           "ERROR!", JOptionPane.ERROR_MESSAGE);
                           return;
				}
				if (javaFile == false) {
					JOptionPane.showMessageDialog(null, "This is not a Java file!",
                           "ERROR!", JOptionPane.ERROR_MESSAGE);
                           return;
				}
				else
					compile(currFile.getPath(), true);
			} });
		toolBar.add(button);
		// decompile
		button = new JButton(new ImageIcon("jsource" + fs + "decompile.jpg"));
        button.setToolTipText("Decompile");
        button.addActionListener(new Decompiler(this));
		toolBar.add(button);
		// run
		inp = new Interpreter(this);
        button = new JButton(new ImageIcon("jsource" + fs + "run.jpg"));
        button.setToolTipText("Run");
        button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				if (editor.getText().equals(""))
                       JOptionPane.showMessageDialog(null, "No file to run!",
                           "ERROR!", JOptionPane.ERROR_MESSAGE);
                else
					inp.run(currentFile, "java", jdk);

            } });
		toolBar.add(button);
		// browse
        button = new JButton(new ImageIcon("jsource" + fs + "browser.jpg"));
        button.setToolTipText("View in Web Browser");
        button.addActionListener(new BrowserListener(this));
		toolBar.add(button);
	}

	/**
	 * setup toolbar1
	 * @author Panagiotis Plevrakis
	 * @author Andrei Erdoss
	 * @param
	 * @return
	 */
	public void setToolBar1(JToolBar toolBar) {
		JComboBox comboBox;
		JButton button;

		// font family
		comboBox = new JComboBox(getFonts());
        comboBox.addActionListener(new FontTypeListener());
		toolBar.add(comboBox);

		// font style
		comboBox = new JComboBox(fontStyles);
        comboBox.setSelectedIndex(0);
        comboBox.addActionListener(new FontStyleListener());
		toolBar.add(comboBox);

		// font size
        comboBox = new JComboBox(fontSizes);
        comboBox.setSelectedIndex(3);
        comboBox.addActionListener(new FontSizeListener());
		toolBar.add(comboBox);

		// font color
        button = new JButton("Font Color");
        button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    currentFgColor = JColorChooser.showDialog(
                                JavaIDE.this, "Choose Font Color",
                                editor.getForeground());
               //     if (currentFgColor != null)
                        editor.setForeground(currentFgColor);
                }
            }
        );
		toolBar.add(button);

		// background color
        button = new JButton("Background Color");
        button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				currentBgColor = JColorChooser.showDialog(
                                JavaIDE.this, "Choose Background Color",
                                editor.getBackground());
               // if (currentBgColor != null)
					editor.setBackground(currentBgColor);
                }
            }
        );
		toolBar.add(button);
	}

	/**
	 * compile
	 * @author Panagiotis Plevrakis
	 * @param String file to compile, boolean thread
	 * @return
	 */
    private void compile(String file, boolean thread) {
        try {
            Compiler compiler = new Compiler(jdk);

            compiler.set(file);

            if (thread)
                compiler.start();
            else
                compiler.run();
        } catch (Exception err) {
            showExceptionErrorMessage("Cannot compile " + file + ".");
        }
    }

	/**
	 * set jdk
	 * @author Panagiotis Plevrakis
	 * @param
	 * @return
	 */
    public void setJavaHome() {
        String rt = root.getParent().toString();
        String s = new String();
        String path;
        JFileChooser jfc_jdk = new JFileChooser(dir);

        jfc_jdk.isDirectorySelectionEnabled();
        jfc_jdk.setFileSelectionMode(1);
        jfc_jdk.setApproveButtonText("Set");
        jfc_jdk.setApproveButtonToolTipText("Set path to JDK bin");
        jfc_jdk.setDialogTitle("Enter full path of your JDK / bin");
        if (jfc_jdk.showOpenDialog(this) == 0) {
            jdk = jfc_jdk.getSelectedFile().getPath();
            try {
                if (f.exists()) f.delete();
                ObjectOutputStream sr = new ObjectOutputStream(new FileOutputStream(f));

                sr.writeObject(jdk);
            } catch (IOException e) {
                f.delete();
            }
            isjdk = true;
            showMessage("Your JDK/bin dir is " + jdk);
        } else
        if (jdk == null) {
            showMessage("Be sure to specify SDK bin path before compiling!");
            isjdk = isjdk;
            jdk = jdk;
            return;
        }
        repaint();
    }

    /**
     * Not used. It simply sets the default Swing L&F. This method exists solely for
     * future modifications of L&F.
     */
    private void setLookAndFeel() {
        UIManager UIM = new UIManager();
        UIManager.LookAndFeelInfo[] installedLnFs = UIM.getInstalledLookAndFeels();

        for (int i = 0; i < installedLnFs.length; i++) {
			//Uncomment next line to get a list of all available L&Fs in the system
			//System.out.println(installedLnFs[i]);
            if (installedLnFs[i].getName().equals("Metal"))
                try {
                    UIM.setLookAndFeel(installedLnFs[i].getClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
        }
    }

	/**
	 * Check to see if a given character is a separator
	 * @author Andrei Erdoss
	 * @param char ch
	 * @return boolean true if a separator
	 */
	boolean isSeparator(char ch) {
		char separators[] = {' ', '\t', '\n', '\r', '\f', '.', ',', ':', '-', '(', ')', '\b',
							 '[', ']', '{', '}', '<', '>', '|', '\\', '\'', '\"', '/', '='};
		for(int i = 0; i < separators.length; i++) {
			if(separators[i] == ch)
				return true;
		}
		return false;
	}

	/**
	 * Check to see if a given string is a keyword
	 * @author Andrei Erdoss
	 * @param String str
	 * @return boolean true if a keyword
	 */
	boolean isKeyword(String str) {
		String keywords[] = {
			"abstract", "boolean", "break", "byte", "case", "catch",
			"char", "class", "const", "continue", "do", "double",
			"else", "extends", "final", "finally", "float", "for",
			"goto", "if", "implements", "import", "instanceof", "int",
			"interface", "long", "native", "new", "package", "private",
			"protected", "public", "return", "short", "static", "strictfp",
			"super", "switch", "synchronized", "this", "throw", "throws",
            "transient", "try", "void", "volatile", "while", "true",
			"false", "null" };
		for(int i = 0; i < keywords.length; i++) {
			if(keywords[i].equals(str)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Sets Kunststoff's custom L&F
	 * @author Panagiotis Plevrakis
	 */
	private void setKunststoffLookAndFeel(DefaultMetalTheme theme) {
		KunststoffLookAndFeel kls = new KunststoffLookAndFeel();
		KunststoffLookAndFeel.setCurrentTheme(theme);
		try {
		    UIManager.setLookAndFeel(kls);
		}
        catch ( Throwable e ) {
            e.printStackTrace();
            System.exit(0);
        }
	}

	/**
	 * Inserts the specified code template
	 * @author Panagiotis Plevrakis
	 */
    private void insertTemplate(File file) {
        try {
            FileReader filereader = new FileReader(file);
            BufferedReader bufferedreader = new BufferedReader(filereader);
			StreamTokenizer st = new StreamTokenizer(bufferedreader);
			st.ordinaryChar(' '); st.ordinaryChar('.');
			st.ordinaryChar('('); st.ordinaryChar(')');
			st.ordinaryChar('/'); st.ordinaryChar('\t');
			st.ordinaryChar('\"'); st.ordinaryChar('\'');
			st.slashSlashComments(false); st.slashStarComments(false);
			st.eolIsSignificant(true);
            while (st.nextToken() != StreamTokenizer.TT_EOF) {
				if(st.ttype == st.TT_WORD) {
					if(isKeyword(st.sval))
					   doc.insertString(editor.getCaretPosition(), ""+st.sval,
										 editor.getStyle("keyword"));
					else
						doc.insertString(editor.getCaretPosition(), ""+st.sval,
								 editor.getStyle("plain"));
				} else if(st.ttype == st.TT_NUMBER) {
					doc.insertString(editor.getCaretPosition(), ""+(int)st.nval,
								 editor.getStyle("plain"));
				} else {
					doc.insertString(editor.getCaretPosition(), ""+(char)st.ttype,
								 editor.getStyle("plain"));
				}
			}
            filereader.close();
		} catch (Exception e) {}
	}
} //end class