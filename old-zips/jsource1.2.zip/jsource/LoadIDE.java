package jsource;

/**
 * @(#)LoadIDE.java	03/29/02
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;

/**
 * LoadIDE is the entry point of the application.
 *
 * @author	Panagiotis Plevrakis
 *
 * Email: pplevrakis@hotmail.com
 * URL:   http://jsource.sourceforge.net/
 */
public class LoadIDE {
    public static void main(String[]args) {
		JDialog.setDefaultLookAndFeelDecorated(true);
		Toolkit.getDefaultToolkit().setDynamicLayout(true);
		String icon = "jsource" + File.separator + "load.jpg";
		new SplashScreen(icon, 7000);
        final JavaIDE ide = new JavaIDE();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        ide.setSize(Math.min(dim.width - 5, 800), Math.min(dim.height - 40, 600));
        ide.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    ide.setVisible(false);
                    ide.dispose();
                    System.exit(0);
                }
            }
        );
        ide.setVisible(true);
        new LoadIDE().deserialize(ide);
        new LoadIDE().checkJdk(ide);
    }

	/**
	 * Deserializes saved paths.
	 * @author Panagiotis Plevrakis
	 */
    public void deserialize(JavaIDE ide) {
        try {
            if (ide.f.exists()) {
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ide.f));

                ide.jdk = (String) ois.readObject();
            }
        } catch (IOException e) {
            System.out.println("\nERROR:  " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("\nERROR:  " + e.getMessage());
        }

        try {
		    if (BrowserListener.ser.exists()) {
		        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(BrowserListener.ser));

		        BrowserListener.browser = (String) ois.readObject();
		    }
		} catch (IOException ex) {
		    System.out.println("\nERROR:  " + ex.getMessage());
		} catch (ClassNotFoundException exx) {
		    System.out.println("\nERROR:  " + exx.getMessage());
        }
    }

	/**
	 * Checks on load if the path to JDK is set.
	 * @author Panagiotis Plevrakis
	 */
    public void checkJdk(JavaIDE ide) {
        if (ide.jdk == null) {
            String message = "Please specify full path to your JDK";

            ide.showMessage(message);
            ide.setJavaHome();
        }
    }
} // end class
