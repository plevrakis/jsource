package jsource;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class FontSizeListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
        JComboBox cb = (JComboBox) e.getSource();

        if (cb.getSelectedIndex() == 0) {
            JavaIDE.currentSize = JavaIDE.sizes[0];
            JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        }
        if (cb.getSelectedIndex() == 1) {
            JavaIDE.currentSize = JavaIDE.sizes[1];
            JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        }
        if (cb.getSelectedIndex() == 2) {
            JavaIDE.currentSize = JavaIDE.sizes[2];
            JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        }
        if (cb.getSelectedIndex() == 3) {
            JavaIDE.currentSize = JavaIDE.sizes[3];
            JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        }
        if (cb.getSelectedIndex() == 4) {
            JavaIDE.currentSize = JavaIDE.sizes[4];
            JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        }
    }
}
