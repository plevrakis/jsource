package jsource;

/**
 * @(#)InternaFrame.java	03/29/02
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 */

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.text.*;
import java.net.URL;

/**
 * InternalFrame makes a new window
 *
 * @author	Andrei Erdoss
 */
public class InternalFrame extends JInternalFrame {
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
	JTextPane editor, browser;
	JScrollPane center;
	Document doc;
	private static StringBuffer sBuf = new StringBuffer();

    public InternalFrame() {
        super("Document #" + (++openFrameCount), true, true, true, true);

        editor = new JTextPane();
        doc = editor.getDocument();
        initStyles(editor);
        editor.addKeyListener(new KeyAdapter() {
			int startPos, endPos;
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();

				if(isKeyword(sBuf.toString())) {
					endPos = editor.getCaretPosition();
					startPos = endPos - sBuf.length();
					try {
					doc.remove(startPos, sBuf.length());
					doc.insertString(startPos, sBuf.toString(), editor.getStyle("keyword"));
					} catch(BadLocationException ble) { System.out.println("Error"); }
				} else {
					editor.setCharacterAttributes(editor.getStyle("plain"), true);
				}
				if(isSeparator(c)) {
					sBuf.setLength(0);
				} else {
					sBuf.append(c);
				}
			}
		});

        center = new JScrollPane(editor, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                    JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		getContentPane().add(center);
        setBackground(Color.black);
        setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        setSize(300,300);
		setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
    }

	protected void initStyles(JTextPane textPane) {
        Style def = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);

        Style sPlain = textPane.addStyle("plain", def);

        Style sKeyword = textPane.addStyle("keyword", def);

        StyleConstants.setBold(sKeyword, true);
        StyleConstants.setForeground(sKeyword, new Color(134,213,55));
    }

	/**
	 * Check to see if a given character is a separator
	 * @author Andrei Erdoss
	 * @param char ch
	 * @return boolean true if a separator
	 */
	boolean isSeparator(char ch) {
		char separators[] = {' ', '\t', '\n', '\r', '\f', '.', ',', ':', '-', '(', ')', '\b',
							 '[', ']', '{', '}', '<', '>', '|', '\\', '\'', '\"', '/', '='};
		for(int i = 0; i < separators.length; i++) {
			if(separators[i] == ch)
				return true;
		}
		return false;
	}

	/**
	 * Check to see if a given string is a keyword
	 * @author Andrei Erdoss
	 * @param String str
	 * @return boolean true if a keyword
	 */
	boolean isKeyword(String str) {
		String keywords[] = {
			"abstract", "boolean", "break", "byte", "case", "catch",
			"char", "class", "const", "continue", "do", "double",
			"else", "extends", "final", "finally", "float", "for",
			"goto", "if", "implements", "import", "instanceof", "int",
			"interface", "long", "native", "new", "package", "private",
			"protected", "public", "return", "short", "static", "strictfp",
			"super", "switch", "synchronized", "this", "throw", "throws",
            "transient", "try", "void", "volatile", "while", "true",
			"false", "null" };
		for(int i = 0; i < keywords.length; i++) {
			if(keywords[i].equals(str)) {
				return true;
			}
		}
		return false;
	}
}
