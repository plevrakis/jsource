package jsource;


/**
 * @(#)Help.java	04/30/02
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 */
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Help is a child frame that displays usage instructions
 *
 * @author	Panagiotis Plevrakis
 *
 * Email: pplevrakis@hotmail.com
 * URL:   http://jsource.sourceforge.net/
 */
public class Help extends JFrame {

	public static final int WINDOW_WIDTH = 550;
	public static final int WINDOW_HEIGHT = 300;

 	private JButton okay = null;
 	private JTextArea text = null;
	private static final String help_file = "help.txt";

    /**
     * Creates a new Help frame
     */
 	public Help(String name) {
		setSize(WINDOW_WIDTH,WINDOW_HEIGHT);
 		center();
		setTitle(name);
 		setBackground(Color.lightGray);
		text = new JTextArea();
		okay = new JButton("OK");
 		okay.addActionListener(new ActionListener() {
			                   public void actionPerformed(ActionEvent e) {
								   setVisible(false);
		 	                       dispose();
	                           }});
 		text.setEditable(false);
	    getHelpText(text);
		getContentPane().add(text, BorderLayout.CENTER);
		getContentPane().add(okay, BorderLayout.SOUTH);
		setVisible(true);
 	}

    /**
     * Displays the contents of the help file in the text area
     */
	public void getHelpText(JTextArea t) {
	 	StringBuffer s = null;
	 	FileInputStream in = null;
		String separator = null;
		String temp = null;

	 	try{
      		separator = System.getProperty("file.separator");
	 		in = new FileInputStream("jsource" + separator + help_file);
	 		int notAtEnd = 1;

 			while(notAtEnd !=-1 && notAtEnd != 0){
	 	 		int size = in.available();
	 	 		byte[] byteBuffer = new byte[size];
	 	 		notAtEnd = in.read(byteBuffer);
	 	 		s = new StringBuffer(size);
	 	 		int count = 0;

	 	 		while(count < size){
	 	 			s.append((char)byteBuffer[count]);
	 	 			count++;
	 	 		}
	 	 	t.append(s.toString());
		 	}
		 	in.close();
	 	} catch(IOException e){
	 	  }
	}

    /**
     * Centering this child frame
     */
	public void center() {
		Toolkit t = Toolkit.getDefaultToolkit();
		Dimension d = t.getScreenSize();
		int wWidth = getInsets().left + getInsets().right + WINDOW_WIDTH;
		int wHeight = getInsets().top + getInsets().bottom + WINDOW_HEIGHT;
        setLocation((d.width/2)-(wWidth/2), (d.height/2)-(wHeight/2));
	}
} // end class