package jsource;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class FontTypeListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
        JComboBox cb = (JComboBox) e.getSource();

        JavaIDE.currentFont = (String) cb.getSelectedItem();
        JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
    }
}
