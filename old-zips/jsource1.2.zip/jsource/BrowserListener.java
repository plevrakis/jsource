package jsource;


/**
 * @(#)BrowserListener.java	04/03/02
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 */
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;


/**
 * BrowserListener opens the system's web browser
 * and displays the currently edited HTML file.
 *
 * @author	Panagiotis Plevrakis
 *
 * Email: pplevrakis@hotmail.com
 * URL:   http://jsource.sourceforge.net/
 */
public class BrowserListener implements ActionListener {
    private JavaIDE ide = null;
    protected static String dir = System.getProperty("user.dir");
    protected static String fs = System.getProperty("file.separator");
    protected static String browser = null;
    protected static File ser = new File("jsource" + fs + "browser.ser");
    private File root = new File(dir);

    protected BrowserListener(JavaIDE ide) {
        this.ide = ide;
    }

    public void actionPerformed(ActionEvent e) {
        if (browser == null) {
            setBrowserHome();
        }
        if (JavaIDE.editor.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "No file to view!", "ERROR!",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (JavaIDE.currentFile == null) {
            JOptionPane.showMessageDialog(null, "No file to view!", "ERROR!",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
    /*    if (JavaIDE.currentFile.endsWith(".html") ||
            JavaIDE.currentFile.endsWith(".HTML") ||
            JavaIDE.currentFile.endsWith(".htm")  ||
            JavaIDE.currentFile.endsWith(".HTM")  ||
            JavaIDE.currentFile.endsWith(".php3") ||
            JavaIDE.currentFile.endsWith(".PHP3") ) {*/
        	try {
            	Runtime r = Runtime.getRuntime();
            	r.exec(browser + " " + ide.currFile.getPath());
        	} catch (Exception ex) {
            	ex.printStackTrace();
            	JOptionPane.showMessageDialog(null, "Not a valid file!", "ERROR!",
				JOptionPane.ERROR_MESSAGE);
		    	return;
        	}
    }

    /**
     * Sets the location of the web browser to be used for HTML file viewing
     * @author Panagiotis Plevrakis
     */
    protected void setBrowserHome() {
        String rt = root.getParent().toString();
        String s = new String();
        String path;
        JFileChooser brs_slt = new JFileChooser();
        ExampleFileFilter filter = new ExampleFileFilter();
        filter.addExtension("exe");
        filter.setDescription("exe");
        brs_slt.setFileFilter(filter);
        brs_slt.isFileSelectionEnabled();
        brs_slt.setApproveButtonText("Set");
        brs_slt.setApproveButtonToolTipText("Set the location of your web browser");
        brs_slt.setDialogTitle("Set the location of your web browser");
		int replycode = brs_slt.showOpenDialog(ide);
		if (replycode == JFileChooser.APPROVE_OPTION) {
            browser = brs_slt.getSelectedFile().getPath();
            try {
                if (ser.exists()) {
					ser.delete();
				}
                ObjectOutputStream sr = new ObjectOutputStream(new FileOutputStream(ser));
                sr.writeObject(browser);
            } catch (IOException e) {
                ser.delete();
            }
            showMessage("Your browser is " + browser);
        } else
        if (browser == null) {
            showMessage("Web browser is not set!");
            return;
        }
    }

    private void showMessage(String s) {
        JOptionPane.showMessageDialog(null, s);
    }
}