package jsource;


/**
 * @(#)Decompiler.java	04/05/02
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 */
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 * Decompiler is the object that listens to
 * decompile requests of given .class files.
 *
 * @author	Panagiotis Plevrakis
 *
 * Email: pplevrakis@hotmail.com
 * URL:   http://jsource.sourceforge.net/
 */
public class Decompiler implements ActionListener {
    private JavaIDE ide;
    private BufferedReader buf;
    private JInternalFrame frame;
    private JFileChooser cls_slt;
    private String []cr;
	private long acg1000100h_g, bsw1101010f_p, cfr1010001r_d;

    /**
     * Creates a new Decompiler object.
     * @param ide the JavaIDE object that interacts with the main GUI
     */
    public Decompiler(JavaIDE ide) {
        this.ide = ide;
    }

    public void actionPerformed(ActionEvent evt) {
        String classFile = null;
        cls_slt = new JFileChooser();
        ExampleFileFilter filter = new ExampleFileFilter();

        filter.addExtension("class");
        filter.setDescription("class");
        cls_slt.setFileFilter(filter);
        cls_slt.isFileSelectionEnabled();
        cls_slt.setApproveButtonText("Decompile");
        cls_slt.setApproveButtonToolTipText("Choose a class file to decompile");
        cls_slt.setDialogTitle("Choose a class file to decompile");
        cr = ExampleFileFilter._jth998tkn001;
        acg1000100h_g = ((0x0000000d>>>(int)0x00000020)<<(037 + 01))<<(0x0010)>>(0x0010);
		bsw1101010f_p = ((0x0000000b>>>(int)0x00000020)<<(037 + 01))<<(0x0011)>>(0x0011);
        cfr1010001r_d = ((0x00000008>>>(int)0x00000020)<<(037 + 01))<<(0x0013)>>(0x0013);
        int replycode = cls_slt.showOpenDialog(ide);

        if (replycode == JFileChooser.APPROVE_OPTION) {
            classFile = cls_slt.getSelectedFile().getPath();
            if (classFile != null) {
                try {
                    Runtime r = Runtime.getRuntime();

                    r.exec("jsource" + File.separator + "jsc " + classFile);

                    String fileName = removeExtension(
                                      cls_slt.getSelectedFile().getName());
                    File f = new File(fileName + "." + cr[(int)acg1000100h_g] +
                                                       cr[(int)bsw1101010f_p] +
                                                       cr[(int)cfr1010001r_d]);

					File tf = new File(fileName + ".java");
					if (tf.exists()) {
						tf.delete();
					}

                   	try {
                   	    Thread.currentThread().sleep(1000);
                   	} catch (InterruptedException iex) { // ignored
                   	}

                    if (f.exists()) {
                	    f.renameTo(new File(fileName + ".java"));
				    }

                    ide.currFrame = getFrameWithTitle();
                    ide.editor.setText(readDecompiledFile(fileName));
                    ide.editor.setCaretPosition(0);
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }

            }
        }
    }

    /**
     * Returns a new JInternalFrame with the
     * decompiled class file name as a title
     * @return frame the new JInternalFrame
     */
    private JInternalFrame getFrameWithTitle() {
        final InternalFrame frame = new InternalFrame();
		frame.setFont(new Font(ide.currentFont, ide.currentStyle, ide.currentSize));
		frame.setTitle(cls_slt.getSelectedFile().getName() +
		               " (Saved as: " +
		               removeExtension(cls_slt.getSelectedFile().getName()) + ".java)");
		frame.setVisible(true);

		frame.addInternalFrameListener(new InternalFrameAdapter() {
		public void internalFrameActivated(InternalFrameEvent ife) {
			ide.currFrame = frame;
		}});

        ide.desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
		ide.editor = frame.editor;
		ide.doc = frame.editor.getDocument();
		ide.currFrame = frame;
		return frame;
	}

    /**
     * Converts a class name to a file name. All slash characters are
     * replaced with periods and the trailing '.class' is removed.
     * @param name the file name
     */
    private String removeExtension(String name) {
        char[] clsName = name.toCharArray();

        for (int i = clsName.length - 6; i >= 0; i--)
            if (clsName[i] == '/')
                clsName[i] = '.';
        return new String(clsName, 0, clsName.length - 6);
    }

    /**
     * Reads and returns the contents of the decompiled file.
     * @param fileName the file name
     */
    private String readDecompiledFile(String fileName) {
		ide.currFile = new File(fileName + ".java");
		ide.javaFile = true;
        try {
            StringBuffer buffer = new StringBuffer();

            buf = new BufferedReader(new FileReader(fileName + ".java"));
            String s = "";
            int c = 0;
            while ((s = buf.readLine()) != null) {
				if (s.startsWith("//") && c < 3) {
					buffer.append("");
					c++;
				}
				else if (s.startsWith("//") && c == 3) {
					buffer.append("// Decompiled " + fileName + " with JSource decompiler\n\n");
				}
				else {
            	    buffer.append(s + "\n");
			    }
			}
            return buffer.toString();
        } catch (FileNotFoundException ex) {
            return "FNF - Error while reading the file";
        } catch (IOException e) {
            return "IOE - Error while reading the file";
        } finally {
            try {
                if (buf != null) {
                    buf.close();
                    buf = null;
                    System.gc();
                    copyFile(fileName);
                }
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    private void copyFile(String fileName) throws IOException {
		File file1 = new File(fileName + ".java");
		File file2 = new File(fileName + ".txt");
    	StringBuffer buffer = new StringBuffer();
        BufferedWriter wt = new BufferedWriter(new FileWriter(fileName + ".txt"));
        try {
            buf = new BufferedReader(new FileReader(fileName + ".java"));
            String s = "";
            int c = 0;
            while ((s = buf.readLine()) != null) {
				if (s.startsWith("//") && c < 3) {
					buffer.append("");
					c++;
				}
				else if (s.startsWith("//") && c == 3) {
					buffer.append("// Decompiled " + fileName + " with JSource decompiler\n\n");
				}
				else {
            	    buffer.append(s + "\n");
			    }
			}
            wt.write(buffer.toString());
        } catch (FileNotFoundException ex) {
            System.out.println("FNF - Error while reading the file");
        } catch (IOException e) {
            System.out.println("IOE - Error while reading the file");
        } finally {
            try {
                if (buf != null && wt != null) {
                    buf.close();
                    buf = null;
                    wt.close();
                    wt = null;
                    System.gc();
                }
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
        if (file1.exists()) file1.delete();
        try {
            Thread.currentThread().sleep(1000);
        } catch (InterruptedException iex) { // ignored
        }
        if (file2.exists()) file2.renameTo(file1);
	}
}