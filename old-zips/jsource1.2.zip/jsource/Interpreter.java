package jsource;


import java.util.*;
import java.io.*;


public class Interpreter {
    JavaIDE editor;
    String fs,ls;

    public Interpreter(JavaIDE edit) {
        editor = edit;
        fs = System.getProperty("file.separator");
        ls = System.getProperty("line.separator");
    }

    public void run(String file, String command, String jdkPath) {
        StatusOutput pop = new StatusOutput("Interpreter");
        String line = new String();
        String gap = " ";
        System.out.println(jdkPath + fs + command + gap + file.trim());
        try {
            Process ps = Runtime.getRuntime().exec(jdkPath + fs + command + gap + file.trim());
            InputStreamReader inp = new InputStreamReader(ps.getInputStream());
            BufferedReader bufred = new BufferedReader(inp);

            while ((line = bufred.readLine()) != null)
                pop.showOutput(line + ls);
            pop.ok.setEnabled(true);
            pop.ok.requestFocus();
            inp.close();
            bufred.close();
        } catch (Exception err) {
            pop.showOutput(ls + "Error running " + file.trim() + ".");
        }
        pop.showOutput(ls + "Finished");
    }
}
