package  jsource;


/**
 * @(#)Compiler.java	03/29/02
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as published
 * by the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 */
import  java.awt.*;
import  java.util.*;
import  java.io.*;
import  javax.swing.*;


/**
 * Compiler is a Thread that compiles a given java file
 *
 * @author	Panagiotis Plevrakis
 *
 * Email: pplevrakis@hotmail.com
 * URL:   http://jsource.sourceforge.net/
 */
public class Compiler extends Thread {
    private String fs, ls, jdkPath, javaFile;

    /**
     * Creates a new Compiler object.
     * @param jdkPath the String that holds the path to javac.exe
     */
    public Compiler(String jdkPath) {
        this.jdkPath = jdkPath;
        fs = System.getProperty("file.separator");
        ls = System.getProperty("line.separator");
    }

    public void set(String file) {
        javaFile = file;
    }

    public void run() {
        StatusOutput  pop = new  StatusOutput("Compiler");

        pop.showOutput("Compiling  " + javaFile + "..." + ls);
        boolean  error = false;

        try {
            Process  ps = Runtime.getRuntime().exec(jdkPath + fs + "javac  " + javaFile);
            InputStream  is = ps.getErrorStream();
            BufferedReader  br = new  BufferedReader(new  InputStreamReader(is));

            String  str = br.readLine();

            if (str != null)
                pop.area.setText("");
            while (str != null) {
                str = br.readLine();
                pop.showOutput("" + str + ls);
            }
            pop.ok.setEnabled(true);
            pop.ok.requestFocus();
            is.close();
        } catch (Exception err) {
            error = true;
            pop.showOutput("Error  compiling  " + javaFile + ".");
        }

        if (!error)
            pop.showOutput("Done  compiling  " + javaFile + "...");
    }
}
