package jsource;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class FontStyleListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
        JComboBox cb = (JComboBox) e.getSource();

        if (cb.getSelectedIndex() == 0) {
            JavaIDE.currentStyle = JavaIDE.styles[0];
            JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        }

        if (cb.getSelectedIndex() == 1) {
            JavaIDE.currentStyle = JavaIDE.styles[1];
            JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        }

        if (cb.getSelectedIndex() == 2) {
            JavaIDE.currentStyle = JavaIDE.styles[2];
            JavaIDE.editor.setFont(new Font(JavaIDE.currentFont, JavaIDE.currentStyle, JavaIDE.currentSize));
        }

    }
}
